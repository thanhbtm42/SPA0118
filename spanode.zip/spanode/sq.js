const sqlite3 = require('sqlite3').verbose();
 
// open the database
let db = new sqlite3.Database('C:/spanode/sap101.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the chinook database.');
});
 
db.serialize(() => {
  db.each(`SELECT username, password  FROM taikhoan`, (err, row) => {
    if (err) {
	console.log("hello");
      console.error(err.message);
    }
    console.log(row.username + "\t" + row.password);
  });
});
 
db.close((err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Close the database connection.');
});