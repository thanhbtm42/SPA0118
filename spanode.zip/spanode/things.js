var express = require('express');
var router = express.Router();
var http = require('http');
var fs = require('fs');

router.get('/', function(req, res){
	http.createServer(function (req, res) {
	fs.readFile('index.html', function(err, data) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  });
});
router.post('/', function(req, res){
   res.send('POST route on things.');
});

//export this router to use in our index.js
module.exports = router;