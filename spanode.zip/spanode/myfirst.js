var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mysql = require('mysql');	
var http = require('http');
var fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
	
// Create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })
let FlagObj = {a:100};
app.use(express.static('Login_v9'));
app.get('/index.html', function (req, res) {
   res.sendFile( __dirname + "/" + "index.html" );
})

app.post('/spa_login', urlencodedParser, function (req, res) {
	let db = new sqlite3.Database('C:/spanode/sap101.db', sqlite3.OPEN_READWRITE, (err) => {
		if (err) {
				console.error(err.message);
			}
		console.log('Connected to the chinook database.');
	});
	db.serialize(() => {
	db.each(`SELECT username, password  FROM taikhoan WHERE username = '` + req.body.username+`' AND password = '`+req.body.pass+`'`, (err, row) => {
		FlagObj.a = 2;
		if (err) {
		console.log("hello");
		  console.error(err.message);
		  FlagObj.a = 1;
		}
		if ( FlagObj.a == 2 ){
			console.log(2);
			fs.readFile('main.html', function(err, data) {
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write(data);
			res.end();
		});
		} 
		console.log(FlagObj.a+"  "+row.username + "\t" + row.password);
		});
	});
 
	db.close((err) => {
	  if (err) {
		console.error(err.message);
	  }
	  console.log('Close the database connection.');
	  if ( FlagObj.a != 2 ){
			fs.readFile('index.html', function(err, data) {
			res.writeHead(200, {'Content-Type': 'text/html'});
			res.write(data);
			res.end();
		});
		}
	});
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})