
class TKRepository {  
  constructor(dao) {
    this.dao = dao
  }

  create(id,name,pass) {
    return this.dao.run(
      'INSERT INTO test.taikhoan (id,username,password) VALUES (?,?,?)',
      [id],[name],[pass])
  }
}	